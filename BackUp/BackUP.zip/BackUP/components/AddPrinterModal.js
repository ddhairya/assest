import { Formik } from "formik";
import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import globalStyles from "../styles/global";
import PrinterModal from "../shared/PrinterModal";
import Icon from 'react-native-vector-icons/AntDesign';
import moment from "moment";

const AddPrinterModal = ({setPrinterModal, addprinter, site_id}) => {
    const date = new Date()
    
    return(

        <View style={globalStyles.container}>
            
            <Formik
                initialValues = {{ 
                    site_id : site_id,
                    printer_model : '', 
                    printer_alias_name : '', 
                    printer_details : '',
                    date_of_purchase : ''+ moment(date).format('DD-MM-YYYY'),  
                    remark:'',              
                }}
                onSubmit = { (values, actions) => {
                    addprinter(values)
                    actions.resetForm()
                    setPrinterModal(false)
                    //console.log(values)
                    
                }}
            >
                {(props) => (
                    <View>
                        <PrinterModal props={props}/>
                        <TouchableOpacity onPress={props.handleSubmit} style={globalStyles.saveButton}> 
                            <View style={globalStyles.secContainer}>
                                <Icon name='printer'  size={30}  />
                                <Text style={globalStyles.saveButtonText}> Add Printer</Text>
                            </View>                
                        </TouchableOpacity>
                    </View>
                )}
            </Formik>
        </View>
    )
}

export default AddPrinterModal;