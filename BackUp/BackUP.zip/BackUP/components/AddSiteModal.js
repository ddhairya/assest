import React from 'react'
import { View, Text, TouchableOpacity, TextInput, ScrollView } from 'react-native'
import globalStyles from "../styles/global";
import Icon from 'react-native-vector-icons/AntDesign';
import { Formik } from "formik";
import * as yup from 'yup'
import SiteModal from "../shared/SiteModal";

const SiteValidation = yup.object({
    emirate:yup.string().min(3)
})

const AddSiteModal = ({addSite, setModalOpen}) => {
    return(

        <View style={globalStyles.container} >
            
                <Formik
                    initialValues={{emirate:'', company:'', outlet:'', phone:''}}
                    validationSchema={SiteValidation}
                    onSubmit={(values,actions) => {
                        addSite(values)
                        actions.resetForm(); 
                        setModalOpen(false)
                        //console.log(values);
                    }}
                >
                    {(props) => (
                        <View>
                            <SiteModal props={props}/>
                            <TouchableOpacity onPress={props.handleSubmit} style={globalStyles.saveButton}> 
                                <View style={globalStyles.secContainer}>
                                    <Icon name='pluscircle'  size={25}  />
                                    <Text style={globalStyles.saveButtonText}> Add Sites</Text>
                                </View>                
                            </TouchableOpacity>
                        </View>
                        
                        
                    )}
                </Formik>
            
        </View>
    )
}

export default AddSiteModal;