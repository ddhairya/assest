import React, { useState } from "react";
import { Text, TouchableOpacity, View, StyleSheet, Modal } from "react-native";
import globalStyles from "../styles/global";
import Icon from "react-native-vector-icons/AntDesign";
import EditEtisalat from "../screens/editEtisalat";

 const EtisalatList = ({netwrk, editEtisalat, delEtisalat}) => {
    const [editEtisalatModalOpen, setEditEtisalatModalOpen] = useState(false)
    return(
        <View>
            <TouchableOpacity >
                <View style={[globalStyles.secContainer]} >
                    <View style={[globalStyles.secLineItemContainer50]}>                        
                        <View style={globalStyles.secLineContainer}>                    
                            <Text style={globalStyles.boldText}>{netwrk.etisalat_plan}  </Text>
                        </View>
                        <View style={globalStyles.secLineContainer} >
                            <Text>{netwrk.etisalat_number} + {netwrk.etisalat_subline} </Text>
                        </View>
                        <View style={globalStyles.secLineContainer}>                    
                            <Text style={globalStyles.boldText}>{netwrk.etisalat_internet}  </Text>
                        </View>
                                       
                    </View> 
                    <View style={globalStyles.secLineItemContainer50}>
                        <View style={globalStyles.secLineContainer} >
                            <Icon name="delete" size={30} style={globalStyles.deleteIcon} onPress={() => delEtisalat(netwrk)}/>  
                            <Icon name="edit" size={30} style={globalStyles.editIcon} onPress={() => setEditEtisalatModalOpen(true)}  /> 
                        </View>                           
                    </View>   
                </View>
            </TouchableOpacity> 
            <Modal visible={editEtisalatModalOpen}>
                <EditEtisalat editEtisalat={editEtisalat} setEditEtisalatModalOpen={setEditEtisalatModalOpen} netwrk={netwrk} />
            </Modal>           
        </View>
    )
}


export default EtisalatList;