import { Formik } from "formik";
import React from "react";
import { Text, View , TextInput, TouchableOpacity} from "react-native";
import globalStyles from "../styles/global";
import SiteModal from "../shared/SiteModal";
import Icon from 'react-native-vector-icons/AntDesign';

const EditSiteModal = ({item, editSite, setEditSiteModalOpen}) => {
    return(
        <View style={globalStyles.container}>
            <Formik
                initialValues={{emirate:item.emirate, company:item.company, outlet:item.outlet, phone:item.phone, id:item.id}}
                onSubmit={(values) => {
                    editSite(values)
                    setEditSiteModalOpen(false)
                }}
            >
                {(props) => (
                    <View>
                        <SiteModal props={props}/>
                        <TouchableOpacity onPress={props.handleSubmit} style={globalStyles.saveButton}> 
                                <View style={globalStyles.secContainer}>
                                    <Icon name='pluscircle'  size={25}  />
                                    <Text style={globalStyles.saveButtonText}> Save Sites</Text>
                                </View>                
                        </TouchableOpacity>
                    </View>
                )}
            </Formik>
            
        </View>
    )
}

export default EditSiteModal;